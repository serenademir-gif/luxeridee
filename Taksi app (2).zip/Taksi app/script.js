
window.lastWhatsAppMessage = "Merhaba, genel bir transfer teklifi almak istiyorum."; 

// WHATSAPP NUMARALARI
const WHATSAPP_NUMBERS = [
    { label: "Rezervasyon & Teklif", number: "905338251989" },
    { label: "Acil Durum & VIP", number: "905391196307" } 
];

/**whatsp */
function openNumberSelection() {
    // Mesajı URL'ye uygun hale getiriyoruz
    const message = encodeURIComponent(window.lastWhatsAppMessage);

    // Modal içindeki linkleri bulma
    const link1 = document.querySelector('.modal-link-1');
    const link2 = document.querySelector('.modal-link-2');

    // Numaraları ve mesajı linklere dinamik olarak entegre etme
    if (link1) {
        link1.setAttribute('href', `https://wa.me/${WHATSAPP_NUMBERS[0].number}?text=${message}`);
    }
    if (link2) {
        link2.setAttribute('href', `https://wa.me/${WHATSAPP_NUMBERS[1].number}?text=${message}`);
    }

    // Modal'ı Bootstrap metotları ile gösterme
    var myModal = new bootstrap.Modal(document.getElementById('numberSelectionModal'));
    myModal.show();
}


function sendToWhatsApp(event) {
    event.preventDefault(); // Formun standart submit (sayfa yenileme) işlemini engelle

    // Form alanlarından değerleri alma
    const kalkis = document.getElementById('kalkis').value;
    const varis = document.getElementById('varis').value;
    const tarih = document.getElementById('tarih').value;
    const saat = document.getElementById('saat').value;
    
    // Seçilen option'ın metnini (display text) alma
    const aracTipiSelect = document.getElementById('arac-tipi');
    const aracTipi = aracTipiSelect.options[aracTipiSelect.selectedIndex].text;

    // WhatsApp için mesajı formatlama
    const message = `*Yeni Transfer Teklifi Talebi*\n\n` +
                    `Kalkış Noktası: ${kalkis}\n` +
                    `Varış Noktası: ${varis}\n` +
                    `Tarih: ${tarih}\n` +
                    `Saat: ${saat}\n` +
                    `Araç Tipi: ${aracTipi}\n\n` +
                    `Lütfen en kısa sürede fiyat teklifinizi iletmenizi rica ediyorum.`;

    // Yeni oluşturulan mesajı global değişkene atama
    window.lastWhatsAppMessage = message;
    
    // Numara Seçim Modalını aç
    openNumberSelection();
}


function setVehicleMessage(message) {
    window.lastWhatsAppMessage = message;
    openNumberSelection(); 
}



document.addEventListener('DOMContentLoaded', () => {
    // Sayfa yüklendiğinde varsayılan WhatsApp mesajını ayarlama
    window.lastWhatsAppMessage = "Merhaba, genel bir transfer teklifi almak istiyorum.";
    
    // index.html'deki Formu JavaScript'e bağlama (HTML'de onsubmit="sendToWhatsApp(event)" olduğu için bu kısım isteğe bağlıdır, ancak temizlik için tutulabilir)
    const form = document.getElementById('offer-request-form');
    if (form) {
        // Bu kısım, HTML'deki onsubmit'i destekler, ek dinleyiciye gerek kalmaz.
        console.log("Form dinleyicisi hazırlandı.");
    }
});